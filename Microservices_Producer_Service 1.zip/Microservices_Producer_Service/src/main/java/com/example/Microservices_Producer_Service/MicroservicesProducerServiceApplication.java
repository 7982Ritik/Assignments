package com.example.Microservices_Producer_Service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicesProducerServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicesProducerServiceApplication.class, args);
	}

}
