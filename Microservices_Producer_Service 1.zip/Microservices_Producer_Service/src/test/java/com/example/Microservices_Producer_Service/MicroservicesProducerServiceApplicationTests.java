package com.example.Microservices_Producer_Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicesProducerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
