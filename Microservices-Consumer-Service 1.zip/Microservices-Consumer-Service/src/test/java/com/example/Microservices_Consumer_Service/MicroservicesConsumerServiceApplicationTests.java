package com.example.Microservices_Consumer_Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicesConsumerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
