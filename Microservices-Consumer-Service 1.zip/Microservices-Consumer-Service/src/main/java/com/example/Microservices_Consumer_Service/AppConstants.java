package com.example.Microservices_Consumer_Service;

public class AppConstants {
	public static String topicName="customer-topic";
	public static String groupId="";
}
